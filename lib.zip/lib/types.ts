export type TransactionRecord = {
  id: string;
  date: string;
  income: number;
  productCost: number;
  otherExpense: number;
  remainingBalance: number;
  notes: string;
  category: string;
  tags: string[];
};

export type MonthlyReport = {
  key?: string;
  month: string;
  income: number;
  cost: number;
  expenses: number;
  netProfit: number;
  cashFlow: number;
  margin: number;
  days?: number;
};

export type Insight = {
  title: string;
  detail: string;
  tone: "good" | "warning" | "neutral";
};

export type Transaction = {
  id: string;
  date: string;       // ISO yyyy-MM-dd
  type: "income" | "expense";
  amount: number;
  category: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
};
