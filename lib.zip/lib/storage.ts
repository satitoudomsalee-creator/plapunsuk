import { createClient } from "@supabase/supabase-js";
import { randomUUID } from "crypto";
import type { Transaction } from "./types";

// Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Missing Supabase environment variables");
}

const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Demo user ID - using the one we seeded
const DEMO_USER_ID = "demo-user-001";

/**
 * Transform Supabase row to Transaction type
 */
function transformRow(row: any): Transaction {
  return {
    id: row.id,
    date: new Date(row.date),
    income: parseFloat(row.income),
    productCost: parseFloat(row.productCost),
    otherExpense: parseFloat(row.otherExpense),
    remainingBalance: parseFloat(row.remainingBalance),
    notes: row.notes || "",
    category: row.categoryId || undefined,
    tags: row.tags || [],
    createdAt: new Date(row.createdAt).toISOString(),
    updatedAt: new Date(row.updatedAt).toISOString(),
  };
}

export async function getAllTransactions(): Promise<Transaction[]> {
  try {
    const { data, error } = await supabase
      .from("Transaction")
      .select("*")
      .eq("userId", DEMO_USER_ID)
      .order("date", { ascending: false });

    if (error) {
      console.error("Supabase error:", error);
      return [];
    }

    return data?.map(transformRow) ?? [];
  } catch (error) {
    console.error("Failed to fetch transactions:", error);
    return [];
  }
}

export async function getTransactionById(id: string): Promise<Transaction | null> {
  try {
    const { data, error } = await supabase
      .from("Transaction")
      .select("*")
      .eq("id", id)
      .eq("userId", DEMO_USER_ID)
      .single();

    if (error || !data) return null;
    return transformRow(data);
  } catch (error) {
    console.error("Failed to fetch transaction:", error);
    return null;
  }
}

export async function createTransaction(
  data: Omit<Transaction, "id" | "createdAt" | "updatedAt">
): Promise<Transaction> {
  const now = new Date().toISOString();
  const id = randomUUID();

  try {
    const { data: row, error } = await supabase
      .from("Transaction")
      .insert({
        id,
        userId: DEMO_USER_ID,
        date: data.date.toISOString(),
        income: data.income,
        productCost: data.productCost,
        otherExpense: data.otherExpense,
        remainingBalance: data.remainingBalance,
        notes: data.notes,
        categoryId: data.category,
        tags: data.tags,
        createdAt: now,
        updatedAt: now,
      })
      .select()
      .single();

    if (error || !row) throw error;
    return transformRow(row);
  } catch (error) {
    console.error("Failed to create transaction:", error);
    throw error;
  }
}

export async function updateTransaction(
  id: string,
  data: Partial<Omit<Transaction, "id" | "createdAt">>
): Promise<Transaction | null> {
  const now = new Date().toISOString();

  try {
    const updateData: any = { updatedAt: now };
    if (data.date) updateData.date = data.date.toISOString();
    if (data.income !== undefined) updateData.income = data.income;
    if (data.productCost !== undefined) updateData.productCost = data.productCost;
    if (data.otherExpense !== undefined) updateData.otherExpense = data.otherExpense;
    if (data.remainingBalance !== undefined) updateData.remainingBalance = data.remainingBalance;
    if (data.notes !== undefined) updateData.notes = data.notes;
    if (data.category !== undefined) updateData.categoryId = data.category;
    if (data.tags !== undefined) updateData.tags = data.tags;

    const { data: row, error } = await supabase
      .from("Transaction")
      .update(updateData)
      .eq("id", id)
      .eq("userId", DEMO_USER_ID)
      .select()
      .single();

    if (error || !row) return null;
    return transformRow(row);
  } catch (error) {
    console.error("Failed to update transaction:", error);
    return null;
  }
}

export async function deleteTransaction(id: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from("Transaction")
      .delete()
      .eq("id", id)
      .eq("userId", DEMO_USER_ID);

    if (error) return false;
    return true;
  } catch (error) {
    console.error("Failed to delete transaction:", error);
    return false;
  }
}
