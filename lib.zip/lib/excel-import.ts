import * as XLSX from "xlsx";
import type { TransactionRecord } from "@/lib/types";

const headerAliases = {
  date: ["date", "วันที่", "day", "transaction date"],
  income: ["income", "revenue", "ยอดขาย", "รายรับ", "sales"],
  productCost: ["product cost", "cost", "ต้นทุน", "cogs", "สินค้า"],
  otherExpense: ["other expense", "expense", "expenses", "ค่าใช้จ่าย", "อื่นๆ"],
  remainingBalance: ["remaining", "balance", "profit", "คงเหลือ", "กำไร", "remaining profit"],
  notes: ["notes", "note", "description", "รายละเอียด", "หมายเหตุ"]
};

function normalize(value: unknown) {
  return String(value ?? "").trim().toLowerCase();
}

function toNumber(value: unknown) {
  if (typeof value === "number") return value;
  const cleaned = String(value ?? "").replace(/[฿,\s]/g, "");
  const parsed = Number(cleaned);
  return Number.isFinite(parsed) ? parsed : 0;
}

function toDate(value: unknown) {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (typeof value === "number") {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) return `${parsed.y}-${String(parsed.m).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`;
  }
  const raw = String(value ?? "").trim();
  const date = new Date(raw);
  return Number.isNaN(date.getTime()) ? raw : date.toISOString().slice(0, 10);
}

function findHeader(headers: string[], aliases: string[]) {
  return headers.findIndex((header) => aliases.some((alias) => header.includes(alias)));
}

function cellAt(row: unknown[], index: number) {
  return index >= 0 ? row[index] : "";
}

export function parseFinanceWorkbook(buffer: ArrayBuffer): TransactionRecord[] {
  const workbook = XLSX.read(buffer, { type: "array", cellDates: true });
  const records: TransactionRecord[] = [];

  workbook.SheetNames.forEach((sheetName) => {
    const sheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: "" });
    const knownHeaders = Object.values(headerAliases).flat();
    const headerRowIndex = rows.findIndex((row) => row.some((cell) => knownHeaders.some((header) => normalize(cell).includes(header))));
    const headerRow = (rows[headerRowIndex] ?? rows[0] ?? []).map(normalize);
    const dataRows = rows.slice(Math.max(headerRowIndex, 0) + 1);
    const indexes = {
      date: findHeader(headerRow, headerAliases.date),
      income: findHeader(headerRow, headerAliases.income),
      productCost: findHeader(headerRow, headerAliases.productCost),
      otherExpense: findHeader(headerRow, headerAliases.otherExpense),
      remainingBalance: findHeader(headerRow, headerAliases.remainingBalance),
      notes: findHeader(headerRow, headerAliases.notes)
    };

    dataRows.forEach((row, rowIndex) => {
      const income = toNumber(cellAt(row, indexes.income));
      const productCost = toNumber(cellAt(row, indexes.productCost));
      const otherExpense = toNumber(cellAt(row, indexes.otherExpense));
      const remainingBalance = indexes.remainingBalance >= 0 ? toNumber(cellAt(row, indexes.remainingBalance)) : income - productCost - otherExpense;
      if (!income && !productCost && !otherExpense && !remainingBalance) return;

      records.push({
        id: `${sheetName}-${rowIndex + 1}`,
        date: indexes.date >= 0 ? toDate(cellAt(row, indexes.date)) : sheetName,
        income,
        productCost,
        otherExpense,
        remainingBalance,
        notes: indexes.notes >= 0 ? String(cellAt(row, indexes.notes) ?? "") : `Imported from ${sheetName}`,
        category: otherExpense > productCost ? "Operating Expense" : "Product Cost",
        tags: [sheetName]
      });
    });
  });

  return records;
}
