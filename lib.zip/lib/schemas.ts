import { z } from "zod";

export const transactionSchema = z.object({
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "รูปแบบวันที่ไม่ถูกต้อง (yyyy-mm-dd)"),
  type: z.enum(["income", "expense"], {
    required_error: "กรุณาเลือกประเภท",
    invalid_type_error: "ประเภทไม่ถูกต้อง",
  }),
  amount: z
    .number({ invalid_type_error: "กรุณาระบุจำนวนเงิน" })
    .positive("จำนวนเงินต้องมากกว่า 0"),
  category: z.string().optional(),
  notes: z.string().optional(),
});

export type TransactionInput = z.infer<typeof transactionSchema>;
