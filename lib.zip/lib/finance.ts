import { format, getDay, isValid, parseISO } from "date-fns";
import { th } from "date-fns/locale";
import type { Insight, MonthlyReport, Transaction, TransactionRecord } from "@/lib/types";

export const currency = new Intl.NumberFormat("th-TH", {
  style: "currency",
  currency: "THB",
  maximumFractionDigits: 0
});

export const numFmt = new Intl.NumberFormat("th-TH");

export function formatDateThai(dateStr: string): string {
  const d = parseISO(dateStr);
  return isValid(d) ? format(d, "d MMM yyyy", { locale: th }) : dateStr;
}

// Convert Transaction[] (CRUD storage format) → TransactionRecord[] (finance functions format)
// Computes a running cumulative remainingBalance
export function adaptTransactions(transactions: Transaction[]): TransactionRecord[] {
  const sorted = [...transactions].sort((a, b) => a.date.localeCompare(b.date));
  let running = 0;
  return sorted.map((t) => {
    const delta = t.type === "income" ? t.amount : -t.amount;
    running += delta;
    return {
      id: t.id,
      date: t.date,
      income: t.type === "income" ? t.amount : 0,
      productCost: 0,
      otherExpense: t.type === "expense" ? t.amount : 0,
      remainingBalance: running,
      notes: t.notes,
      category: t.category || "อื่นๆ",
      tags: [],
    };
  });
}

// Group TransactionRecord[] by calendar month → MonthlyReport[]
export function groupByMonth(records: TransactionRecord[]): MonthlyReport[] {
  const map = new Map<string, MonthlyReport>();
  for (const r of records) {
    const key = r.date.slice(0, 7); // "2026-05"
    if (!map.has(key)) {
      const parsed = parseISO(r.date);
      const monthLabel = isValid(parsed)
        ? format(parsed, "MMM yy", { locale: th })
        : key;
      map.set(key, { key, month: monthLabel, income: 0, cost: 0, expenses: 0, netProfit: 0, cashFlow: 0, margin: 0, days: 0 });
    }
    const m = map.get(key)!;
    m.income += r.income;
    m.cost += r.productCost;
    m.expenses += r.otherExpense;
    m.days = (m.days ?? 0) + 1;
  }
  return Array.from(map.values())
    .sort((a, b) => (a.key ?? "").localeCompare(b.key ?? ""))
    .map((m) => ({
      ...m,
      netProfit: m.income - m.cost - m.expenses,
      cashFlow: m.income - m.cost - m.expenses,
      margin: m.income > 0 ? (m.income - m.cost - m.expenses) / m.income : 0,
    }));
}

export function summarizeTransactions(records: TransactionRecord[]) {
  const totalIncome = records.reduce((sum, item) => sum + item.income, 0);
  const totalCost = records.reduce((sum, item) => sum + item.productCost, 0);
  const totalExpenses = records.reduce((sum, item) => sum + item.otherExpense, 0);
  const netProfit = totalIncome - totalCost - totalExpenses;
  const remainingCashFlow = records.at(-1)?.remainingBalance ?? netProfit;
  const profitMargin = totalIncome ? netProfit / totalIncome : 0;

  return { totalIncome, totalCost, totalExpenses, netProfit, remainingCashFlow, profitMargin };
}

export function dailySeries(records: TransactionRecord[]) {
  return records.map((item) => {
    const parsedDate = parseISO(item.date);
    return {
      date: isValid(parsedDate) ? format(parsedDate, "d MMM", { locale: th }) : item.date,
      income: item.income,
      expenses: item.productCost + item.otherExpense,
      profit: item.remainingBalance,
      cashFlow: item.remainingBalance
    };
  });
}

export function expenseBreakdown(records: TransactionRecord[]) {
  const totals = new Map<string, number>();
  records.forEach((item) => {
    totals.set(item.category, (totals.get(item.category) ?? 0) + item.otherExpense + item.productCost * 0.18);
  });

  return Array.from(totals, ([name, value]) => ({ name, value: Math.round(value) })).sort((a, b) => b.value - a.value);
}

export function monthlyReports(months: MonthlyReport[]) {
  return months.map((item, index) => {
    const previous = months[index - 1];
    const growth = previous ? (item.netProfit - previous.netProfit) / Math.max(previous.netProfit, 1) : 0;
    return { ...item, growth };
  });
}

export function generateInsights(records: TransactionRecord[], months: MonthlyReport[]): Insight[] {
  const current = summarizeTransactions(records);
  const lastMonth = months.at(-2);
  const thisMonth = months.at(-1);
  const weekdayTotals = new Map<number, number>();

  records.forEach((item, index) => {
    const parsedDate = parseISO(item.date);
    const day = isValid(parsedDate) ? getDay(parsedDate) : index % 7;
    weekdayTotals.set(day, (weekdayTotals.get(day) ?? 0) + item.income);
  });

  const bestDay = Array.from(weekdayTotals.entries()).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 5;
  const weekdays = ["อาทิตย์", "จันทร์", "อังคาร", "พุธ", "พฤหัสบดี", "ศุกร์", "เสาร์"];
  const expenseShift = lastMonth && thisMonth && lastMonth.expenses ? (thisMonth.expenses - lastMonth.expenses) / lastMonth.expenses : 0;
  const marginShift = lastMonth && thisMonth ? thisMonth.margin - lastMonth.margin : 0;
  const bestMonth = [...months].sort((a, b) => b.netProfit - a.netProfit)[0];

  return [
    {
      title: bestMonth ? `เดือนที่กำไรดีที่สุดคือ ${bestMonth.month}` : "ยังไม่มีข้อมูลรายเดือน",
      detail: bestMonth ? `กำไรสุทธิ ${currency.format(bestMonth.netProfit)} จากรายรับ ${currency.format(bestMonth.income)}` : "นำเข้า Excel หรือเพิ่มรายการเพื่อสร้างรายงานรายเดือน",
      tone: "good"
    },
    {
      title: `${expenseShift >= 0 ? "ค่าใช้จ่ายเพิ่มขึ้น" : "ค่าใช้จ่ายลดลง"} ${Math.abs(expenseShift * 100).toFixed(0)}%`,
      detail: "ควรติดตามค่าใช้จ่ายอื่นและต้นทุนสินค้า เพื่อดูว่ากำไรรั่วตรงไหน",
      tone: expenseShift > 0.08 ? "warning" : "neutral"
    },
    {
      title: `วันที่ขายดีที่สุดอยู่ในรอบวัน${weekdays[bestDay]}`,
      detail: "ใช้รูปแบบวันที่ขายดีช่วยวางแผนสต็อกสินค้าและกำลังคน",
      tone: "good"
    },
    {
      title: `อัตรากำไรสุทธิ ${(current.profitMargin * 100).toFixed(1)}%`,
      detail: marginShift < 0 ? "มาร์จินลดลงเมื่อเทียบกับเดือนก่อน" : "มาร์จินยังอยู่ในระดับที่ดีเมื่อเทียบกับเดือนก่อน",
      tone: marginShift < 0 ? "warning" : "good"
    },
    {
      title: records.length > 0 ? "ธุรกิจยังมีกำไรสุทธิเป็นบวก" : "ยังไม่มีข้อมูลรายการ",
      detail: records.length > 0 ? "ภาพรวมยังดี แต่ควรตรวจรายการค่าใช้จ่ายท้ายเดือนอย่างใกล้ชิด" : "เพิ่มรายการรายรับ-รายจ่ายเพื่อดูข้อมูลเชิงลึก",
      tone: records.length > 0 ? "good" : "neutral"
    }
  ];
}
