#!/usr/bin/env node

const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

require('dotenv').config({ path: path.join(__dirname, '../.env.local') });

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  console.error('❌ DATABASE_URL not found in .env.local');
  process.exit(1);
}

const pool = new Pool({ connectionString: DATABASE_URL });

// Helper to generate UUID
function generateUUID() {
  return crypto.randomUUID();
}

async function runMigrations() {
  console.log('🔧 Running database migrations...');

  const sqlFile = path.join(__dirname, '../prisma/migrations/init.sql');
  const sql = fs.readFileSync(sqlFile, 'utf-8');

  try {
    // Split by semicolon and filter out empty statements
    const statements = sql.split(';').filter(s => s.trim());

    for (const statement of statements) {
      if (statement.trim()) {
        await pool.query(statement);
      }
    }
    console.log('✅ Migrations completed');
  } catch (error) {
    if (error.message.includes('already exists')) {
      console.log('⚠️  Tables already exist, skipping migration');
    } else {
      throw error;
    }
  }
}

async function seedDemoData() {
  console.log('🌱 Seeding demo data...');

  const userId = generateUUID();
  const demoEmail = 'demo@finora-sme.local';

  try {
    // Insert demo user
    await pool.query(
      `INSERT INTO "User" (id, email, name, "businessName", currency, locale, "createdAt", "updatedAt")
       VALUES ($1, $2, $3, $4, $5, $6, NOW(), NOW())
       ON CONFLICT (email) DO NOTHING`,
      [userId, demoEmail, 'Demo User', 'Finora Demo Co.', 'THB', 'th-TH']
    );

    // Insert expense categories
    const categories = [
      { name: 'ค่าเช่า', color: '#FB7185', icon: 'Home' },
      { name: 'เงินเดือนพนักงาน', color: '#FBBF24', icon: 'Users' },
      { name: 'ค่าโฆษณา', color: '#7DD3FC', icon: 'TrendingUp' },
      { name: 'ค่ากระแสไฟ', color: '#A78BFA', icon: 'Zap' },
      { name: 'อื่นๆ', color: '#6B7280', icon: 'MoreHorizontal' }
    ];

    const categoryIds = {};
    for (const cat of categories) {
      const catId = generateUUID();
      await pool.query(
        `INSERT INTO "ExpenseCategory" (id, "userId", name, color, icon, "isDefault")
         VALUES ($1, $2, $3, $4, $5, $6)
         ON CONFLICT DO NOTHING`,
        [catId, userId, cat.name, cat.color, cat.icon, cat.name === 'อื่นๆ']
      );
      categoryIds[cat.name] = catId;
    }

    // Generate 90 days of sample transactions
    const now = new Date();
    const transactions = [];

    for (let i = 90; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);

      // Daily income
      const income = 5000 + Math.random() * 10000;

      // Random expenses
      const productCost = 2000 + Math.random() * 3000;
      const otherExpense = 1000 + Math.random() * 2000;
      const remainingBalance = income - productCost - otherExpense;

      transactions.push({
        id: generateUUID(),
        userId,
        date,
        income: parseFloat(income.toFixed(2)),
        productCost: parseFloat(productCost.toFixed(2)),
        otherExpense: parseFloat(otherExpense.toFixed(2)),
        remainingBalance: parseFloat(remainingBalance.toFixed(2))
      });
    }

    // Bulk insert transactions
    for (const tx of transactions) {
      await pool.query(
        `INSERT INTO "Transaction"
         (id, "userId", date, kind, income, "productCost", "otherExpense", "remainingBalance", "createdAt", "updatedAt")
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW(), NOW())`,
        [tx.id, tx.userId, tx.date, 'INCOME', tx.income, tx.productCost, tx.otherExpense, tx.remainingBalance]
      );
    }

    console.log(`✅ Seeded demo user: ${demoEmail}`);
    console.log(`✅ Created ${categories.length} expense categories`);
    console.log(`✅ Created ${transactions.length} sample transactions (90 days)`);
    console.log('\n📝 Demo Credentials:');
    console.log(`   Email: ${demoEmail}`);
    console.log(`   (Use for testing, no password required in this setup)\n`);

  } catch (error) {
    console.error('❌ Error seeding data:', error.message);
    throw error;
  }
}

async function testConnection() {
  console.log('🧪 Testing database connection...');
  try {
    const result = await pool.query('SELECT NOW()');
    console.log('✅ Connection successful:', result.rows[0]);
  } catch (error) {
    console.error('❌ Connection failed:', error.message);
    throw error;
  }
}

async function main() {
  try {
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('  Finora SME - Database Setup');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    await testConnection();
    await runMigrations();
    await seedDemoData();

    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('✅ Setup complete! Ready to run the app.');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

  } catch (error) {
    console.error('❌ Setup failed:', error);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();
