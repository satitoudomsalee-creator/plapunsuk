import { AppShell } from "@/components/app-shell";
import { ImportUploader } from "@/components/import-uploader";
import { Panel } from "@/components/panel";
import { Building2, Settings } from "lucide-react";

export default function SettingsPage() {
  return (
    <AppShell title="ตั้งค่า" subtitle="จัดการไฟล์ Excel สกุลเงิน หมวดหมู่ และข้อมูลธุรกิจ">
      <div className="grid gap-6 xl:grid-cols-[1fr_.8fr]">
        <Panel title="นำเข้าไฟล์ Excel" icon={<Settings size={18} className="text-mint" />}>
          <ImportUploader />
        </Panel>
        <Panel title="ตั้งค่าธุรกิจ" icon={<Building2 size={18} className="text-mint" />}>
          <div className="space-y-4">
            <label className="block">
              <span className="text-sm font-medium text-slate-500">สกุลเงิน</span>
              <input
                className="mt-2 w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition placeholder:text-slate-400 focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
                defaultValue="THB - บาทไทย"
              />
            </label>
            <label className="block">
              <span className="text-sm font-medium text-slate-500">ประเภทธุรกิจ</span>
              <input
                className="mt-2 w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition placeholder:text-slate-400 focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
                defaultValue="ร้านค้า / คาเฟ่ / บริการ"
              />
            </label>
            <label className="block">
              <span className="text-sm font-medium text-slate-500">รอบรายงานเริ่มต้น</span>
              <input
                className="mt-2 w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition placeholder:text-slate-400 focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
                defaultValue="รายเดือน"
              />
            </label>
            <button className="mt-2 w-full rounded-full bg-mint py-3 font-semibold text-white shadow-glow transition hover:bg-ocean active:scale-95">
              บันทึกการตั้งค่า
            </button>
          </div>
        </Panel>
      </div>
    </AppShell>
  );
}
