import Link from "next/link";
import { ArrowRight, Building2, FileSpreadsheet, Sparkles } from "lucide-react";

const steps = [
  { icon: Building2, title: "ตั้งค่าธุรกิจ", copy: "กำหนดสกุลเงิน ภาษา ยอดเริ่มต้น และเดือนที่เริ่มรายงาน", color: "#0EA5E9" },
  { icon: FileSpreadsheet, title: "นำเข้า Excel", copy: "ระบบจับชีตรายเดือนและแถวรายรับ-ค่าใช้จ่ายอัตโนมัติ", color: "#6366F1" },
  { icon: Sparkles, title: "ดูข้อมูลเชิงลึก", copy: "แปลงกำไร ต้นทุน และยอดคงเหลือให้เป็นสัญญาณการดำเนินงาน", color: "#10B981" }
];

export default function OnboardingPage() {
  return (
    <main className="relative min-h-screen overflow-hidden px-4 py-10">
      <div className="soft-grid pointer-events-none absolute inset-0 opacity-60" />
      <section className="relative mx-auto max-w-5xl">
        <div className="mx-auto max-w-2xl text-center">
          <span className="inline-block rounded-full bg-mint/10 px-4 py-1.5 text-sm font-semibold uppercase tracking-[0.22em] text-mint">Onboarding</span>
          <h1 className="mt-5 text-4xl font-bold tracking-tight text-ink sm:text-6xl">เปลี่ยน Excel ให้เป็นแดชบอร์ดการเงินสด</h1>
          <p className="mt-5 text-slate-500">อัปโหลด Excel ครั้งเดียว ตรวจสอบข้อมูล แล้วจัดการการเงินรายวันพร้อมรายงานที่อ่านง่ายและการแจ้งเตือนอัจฉริยะ</p>
        </div>
        <div className="mt-10 grid gap-4 md:grid-cols-3">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div key={step.title} className="glass rounded-3xl p-7">
                <div className="grid h-13 w-13 place-items-center rounded-2xl p-3" style={{ backgroundColor: `${step.color}15` }}>
                  <Icon size={24} style={{ color: step.color }} />
                </div>
                <h2 className="mt-6 text-xl font-bold text-ink">{step.title}</h2>
                <p className="mt-2 text-sm text-slate-500">{step.copy}</p>
              </div>
            );
          })}
        </div>
        <div className="mt-10 text-center">
          <Link href="/dashboard" className="inline-flex items-center gap-2 rounded-full bg-mint px-7 py-3.5 font-semibold text-white shadow-glow transition hover:bg-ocean active:scale-95">
            เข้าสู่แดชบอร์ด
            <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </main>
  );
}
