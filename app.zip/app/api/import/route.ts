import { NextResponse } from "next/server";
import { z } from "zod";
import { parseFinanceWorkbook } from "@/lib/excel-import";
import { expenseBreakdown, generateInsights, summarizeTransactions } from "@/lib/finance";
import { historicalMonths } from "@/data/sample-finance";

export const runtime = "nodejs";

const uploadSchema = z.object({
  name: z.string().min(1)
});

export async function POST(request: Request) {
  const formData = await request.formData();
  const file = formData.get("file");

  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Missing Excel file." }, { status: 400 });
  }

  const parsed = uploadSchema.safeParse({ name: file.name });
  if (!parsed.success || !/\.(xlsx|xls|csv)$/i.test(file.name)) {
    return NextResponse.json({ error: "Please upload a valid Excel or CSV report." }, { status: 400 });
  }

  const records = parseFinanceWorkbook(await file.arrayBuffer());
  const summary = summarizeTransactions(records);

  return NextResponse.json({
    fileName: file.name,
    records,
    summary,
    expenseBreakdown: expenseBreakdown(records),
    insights: generateInsights(records, historicalMonths),
    detectedSchema: {
      tables: ["users", "transactions", "expense_categories", "monthly_summary", "reports"],
      fields: ["date", "income", "productCost", "otherExpense", "remainingBalance", "notes", "category", "tags"]
    }
  });
}
