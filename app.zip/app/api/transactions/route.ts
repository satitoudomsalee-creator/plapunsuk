import { NextResponse } from "next/server";
import { getAllTransactions, createTransaction } from "@/lib/storage";
import { transactionSchema } from "@/lib/schemas";

export const runtime = "nodejs";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const from = searchParams.get("from");
  const to = searchParams.get("to");
  const type = searchParams.get("type");
  const category = searchParams.get("category");

  let transactions = await getAllTransactions();

  if (from) transactions = transactions.filter((t) => t.date >= from);
  if (to) transactions = transactions.filter((t) => t.date <= to);
  if (type === "income" || type === "expense") {
    transactions = transactions.filter((t) => t.type === type);
  }
  if (category) {
    transactions = transactions.filter((t) => t.category === category);
  }

  transactions.sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));

  return NextResponse.json(transactions);
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });

  const parsed = transactionSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "Validation failed", details: parsed.error.flatten() },
      { status: 400 }
    );
  }

  const transaction = await createTransaction({
    date: parsed.data.date,
    type: parsed.data.type,
    amount: parsed.data.amount,
    category: parsed.data.category ?? "",
    notes: parsed.data.notes ?? "",
  });

  return NextResponse.json(transaction, { status: 201 });
}
