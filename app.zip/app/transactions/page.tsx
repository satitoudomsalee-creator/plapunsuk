"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { format, isValid, parseISO } from "date-fns";
import { th } from "date-fns/locale";
import {
  ChevronLeft,
  ChevronRight,
  Filter,
  Inbox,
  Pencil,
  Plus,
  Search,
  Trash2,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { TransactionModal } from "@/components/TransactionModal";
import { useToast } from "@/components/Toast";
import type { Transaction } from "@/lib/types";
import { cn } from "@/lib/utils";

const PAGE_SIZE = 20;

const numFmt = new Intl.NumberFormat("th-TH");
function fmtDate(d: string) {
  const p = parseISO(d);
  return isValid(p) ? format(p, "d MMM yyyy", { locale: th }) : d;
}

export default function TransactionsPage() {
  const { addToast } = useToast();

  // Data
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<"create" | "edit">("create");
  const [editingTx, setEditingTx] = useState<Transaction | undefined>();

  // Filters
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState<"" | "income" | "expense">("");
  const [fromDate, setFromDate] = useState("");
  const [toDate, setToDate] = useState("");

  // Pagination
  const [page, setPage] = useState(1);

  const fetchAll = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/transactions");
      setTransactions(await res.json());
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  // Reset page when filters change
  useEffect(() => setPage(1), [query, typeFilter, fromDate, toDate]);

  const filtered = useMemo(() => {
    return transactions.filter((t) => {
      if (typeFilter && t.type !== typeFilter) return false;
      if (fromDate && t.date < fromDate) return false;
      if (toDate && t.date > toDate) return false;
      if (query) {
        const q = query.toLowerCase();
        if (!`${t.notes} ${t.category}`.toLowerCase().includes(q)) return false;
      }
      return true;
    });
  }, [transactions, query, typeFilter, fromDate, toDate]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paginated = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  async function handleDelete(id: string) {
    if (!window.confirm("ยืนยันการลบรายการนี้?")) return;
    // Optimistic
    setTransactions((prev) => prev.filter((t) => t.id !== id));
    const res = await fetch(`/api/transactions/${id}`, { method: "DELETE" });
    if (res.ok) {
      addToast("ลบรายการแล้ว");
    } else {
      addToast("เกิดข้อผิดพลาดในการลบ", "error");
      fetchAll();
    }
  }

  function openCreate() {
    setModalMode("create");
    setEditingTx(undefined);
    setModalOpen(true);
  }

  function openEdit(t: Transaction) {
    setModalMode("edit");
    setEditingTx(t);
    setModalOpen(true);
  }

  function handleSuccess(t: Transaction) {
    if (modalMode === "create") {
      setTransactions((prev) => [t, ...prev]);
    } else {
      setTransactions((prev) => prev.map((x) => (x.id === t.id ? t : x)));
    }
  }

  return (
    <AppShell
      title="รายการรายวัน"
      subtitle="รายรับ-รายจ่ายทั้งหมด พร้อมค้นหาและกรอง"
      headerRight={
        <button
          onClick={openCreate}
          className="inline-flex items-center gap-2 rounded-full bg-mint px-4 py-2 text-sm font-semibold text-white shadow-glow transition hover:bg-ocean active:scale-95"
        >
          <Plus size={16} />
          เพิ่มรายการ
        </button>
      }
    >
      {/* Filters */}
      <div className="glass mb-4 rounded-2xl p-4">
        <div className="flex flex-wrap gap-3">
          {/* Search */}
          <div className="flex min-w-[200px] flex-1 items-center gap-2 rounded-xl border border-line bg-slate-50/60 px-3 py-2.5">
            <Search size={16} className="shrink-0 text-slate-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ค้นหาหมวดหมู่หรือบันทึก"
              className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-slate-400"
            />
          </div>
          {/* Type filter */}
          <div className="flex items-center gap-2 rounded-xl border border-line bg-slate-50/60 px-3 py-2.5">
            <Filter size={16} className="text-slate-400" />
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as "" | "income" | "expense")}
              className="bg-transparent text-sm text-ink outline-none"
            >
              <option value="">ทั้งหมด</option>
              <option value="income">รายรับ</option>
              <option value="expense">รายจ่าย</option>
            </select>
          </div>
          {/* Date range */}
          <div className="flex items-center gap-2">
            <input
              type="date"
              value={fromDate}
              onChange={(e) => setFromDate(e.target.value)}
              className="rounded-xl border border-line bg-slate-50/60 px-3 py-2.5 text-sm text-ink outline-none focus:border-mint/40"
              placeholder="จาก"
              title="จากวันที่"
            />
            <span className="text-slate-400 text-sm">—</span>
            <input
              type="date"
              value={toDate}
              onChange={(e) => setToDate(e.target.value)}
              className="rounded-xl border border-line bg-slate-50/60 px-3 py-2.5 text-sm text-ink outline-none focus:border-mint/40"
              placeholder="ถึง"
              title="ถึงวันที่"
            />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="glass rounded-2xl p-6">
        {loading ? (
          <div className="flex items-center justify-center py-20 text-slate-400">
            <div className="h-8 w-8 animate-spin rounded-full border-2 border-mint border-t-transparent" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center py-20 text-center">
            <Inbox size={48} className="text-slate-300" />
            <p className="mt-4 text-lg font-semibold text-slate-500">
              {transactions.length === 0 ? "ยังไม่มีรายการ" : "ไม่พบรายการที่ค้นหา"}
            </p>
            <p className="mt-1 text-sm text-slate-400">
              {transactions.length === 0 ? "เริ่มต้นด้วยการเพิ่มรายการรายรับหรือรายจ่าย" : "ลองเปลี่ยนคำค้นหาหรือตัวกรอง"}
            </p>
            {transactions.length === 0 && (
              <button
                onClick={openCreate}
                className="mt-5 inline-flex items-center gap-2 rounded-full bg-mint px-5 py-2.5 text-sm font-semibold text-white shadow-glow transition hover:bg-ocean active:scale-95"
              >
                <Plus size={16} />
                เพิ่มรายการแรก
              </button>
            )}
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[780px] text-left text-sm">
                <thead className="text-xs uppercase tracking-[0.14em] text-slate-400">
                  <tr className="border-b border-line">
                    <th className="pb-3 pr-4">วันที่</th>
                    <th className="pb-3 pr-4">ประเภท</th>
                    <th className="pb-3 pr-4 text-right">จำนวนเงิน</th>
                    <th className="pb-3 pr-4">หมวดหมู่</th>
                    <th className="pb-3 pr-4">บันทึก</th>
                    <th className="pb-3">จัดการ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  {paginated.map((t) => (
                    <tr key={t.id} className="group hover:bg-slate-50/60 transition">
                      <td className="py-3.5 pr-4 font-medium text-ink">{fmtDate(t.date)}</td>
                      <td className="py-3.5 pr-4">
                        <span
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold",
                            t.type === "income"
                              ? "bg-mint/10 text-mint"
                              : "bg-rose-50 text-coral"
                          )}
                        >
                          {t.type === "income" ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                          {t.type === "income" ? "รายรับ" : "รายจ่าย"}
                        </span>
                      </td>
                      <td className={cn("py-3.5 pr-4 text-right font-bold tabular-nums", t.type === "income" ? "text-mint" : "text-coral")}>
                        {t.type === "expense" ? "−" : ""}฿{numFmt.format(t.amount)}
                      </td>
                      <td className="py-3.5 pr-4">
                        {t.category ? (
                          <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">
                            {t.category}
                          </span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="max-w-[200px] truncate py-3.5 pr-4 text-slate-400">
                        {t.notes || "—"}
                      </td>
                      <td className="py-3.5">
                        <div className="flex gap-1.5">
                          <button
                            onClick={() => openEdit(t)}
                            className="grid h-8 w-8 place-items-center rounded-lg bg-slate-100 text-slate-500 transition hover:bg-mint/10 hover:text-mint"
                            title="แก้ไข"
                          >
                            <Pencil size={14} />
                          </button>
                          <button
                            onClick={() => handleDelete(t.id)}
                            className="grid h-8 w-8 place-items-center rounded-lg bg-slate-100 text-slate-500 transition hover:bg-rose-50 hover:text-coral"
                            title="ลบ"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-5 flex items-center justify-between text-sm text-slate-500">
                <span>
                  แสดง {(currentPage - 1) * PAGE_SIZE + 1}–{Math.min(currentPage * PAGE_SIZE, filtered.length)} จาก {filtered.length} รายการ
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    className="grid h-8 w-8 place-items-center rounded-lg border border-line bg-white transition hover:bg-slate-50 disabled:opacity-40"
                  >
                    <ChevronLeft size={16} />
                  </button>
                  <span className="font-medium text-ink">{currentPage} / {totalPages}</span>
                  <button
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                    disabled={currentPage === totalPages}
                    className="grid h-8 w-8 place-items-center rounded-lg border border-line bg-white transition hover:bg-slate-50 disabled:opacity-40"
                  >
                    <ChevronRight size={16} />
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      <TransactionModal
        open={modalOpen}
        mode={modalMode}
        initialData={editingTx}
        onSuccess={handleSuccess}
        onClose={() => setModalOpen(false)}
      />
    </AppShell>
  );
}
