import { AppShell } from "@/components/app-shell";
import { MetricCard } from "@/components/metric-card";
import { MonthlyComparison, ProfitLine } from "@/components/charts";
import { Panel } from "@/components/panel";
import { getAllTransactions } from "@/lib/storage";
import { adaptTransactions, currency, dailySeries, groupByMonth, summarizeTransactions } from "@/lib/finance";
import { LineChart, Receipt, TrendingUp, Wallet } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ProfitLossPage() {
  const raw = await getAllTransactions();
  const transactions = adaptTransactions(raw);
  const monthly = groupByMonth(transactions);
  const summary = summarizeTransactions(transactions);
  const series = dailySeries(transactions);

  const rows = [
    ["รายรับรวม", summary.totalIncome],
    ["ต้นทุนสินค้า", -summary.totalCost],
    ["ค่าใช้จ่ายอื่น", -summary.totalExpenses],
    ["กำไรสุทธิ", summary.netProfit],
    ["อัตรากำไร", `${(summary.profitMargin * 100).toFixed(1)}%`]
  ];

  return (
    <AppShell title="กำไรขาดทุน" subtitle="สรุปรายรับ ต้นทุน ค่าใช้จ่าย และกำไรสุทธิจากข้อมูลจริง">
      <div className="grid gap-4 md:grid-cols-3">
        <MetricCard label="รายรับรวม" value={summary.totalIncome} trend={12.4} data={series.map((item) => ({ value: item.income }))} accent="#0EA5E9" icon={<TrendingUp size={16} color="#0EA5E9" />} />
        <MetricCard label="ต้นทุนรวม" value={summary.totalCost} trend={5.2} data={series.map((item) => ({ value: item.expenses }))} accent="#F43F5E" icon={<Receipt size={16} color="#F43F5E" />} />
        <MetricCard label="กำไรสุทธิ" value={summary.netProfit} trend={6.8} data={series.map((item) => ({ value: item.profit }))} accent="#10B981" icon={<Wallet size={16} color="#10B981" />} />
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-[.8fr_1.2fr]">
        <Panel title="งบกำไรขาดทุน" icon={<LineChart size={18} className="text-mint" />}>
          <div className="space-y-2">
            {rows.map(([label, value]) => (
              <div key={String(label)} className="flex items-center justify-between rounded-xl bg-slate-50/80 px-4 py-3.5">
                <span className="text-sm text-slate-600">{label}</span>
                <span className="font-bold text-ink">{typeof value === "number" ? currency.format(value) : value}</span>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="แนวโน้มกำไร">
          <ProfitLine data={series} />
        </Panel>
      </div>
      <div className="mt-6">
        <Panel title="เปรียบเทียบกำไรขาดทุนรายเดือน">
          <MonthlyComparison data={monthly} />
        </Panel>
      </div>
    </AppShell>
  );
}
