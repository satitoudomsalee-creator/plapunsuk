import { AppShell } from "@/components/app-shell";
import { ExpensePie, MonthlyComparison, RevenueTrend } from "@/components/charts";
import { Panel } from "@/components/panel";
import { Insights } from "@/components/insights";
import { getAllTransactions } from "@/lib/storage";
import {
  adaptTransactions,
  dailySeries,
  expenseBreakdown,
  generateInsights,
  groupByMonth,
} from "@/lib/finance";
import { BarChart3, PieChart, TrendingUp } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AnalyticsPage() {
  const raw = await getAllTransactions();
  const transactions = adaptTransactions(raw);
  const monthly = groupByMonth(transactions);
  const series = dailySeries(transactions);

  return (
    <AppShell title="วิเคราะห์ธุรกิจ" subtitle="ดูแนวโน้มรายรับ ค่าใช้จ่าย และสัญญาณที่ควรติดตาม">
      <div className="grid gap-6 xl:grid-cols-[1.35fr_.75fr]">
        <Panel title="แนวโน้มรายรับ" icon={<TrendingUp size={18} className="text-mint" />}>
          <RevenueTrend data={series} />
        </Panel>
        <Panel title="ข้อมูลเชิงลึก">
          <Insights insights={generateInsights(transactions, monthly)} />
        </Panel>
      </div>
      <div className="mt-6 grid gap-6 xl:grid-cols-[.8fr_1.2fr]">
        <Panel title="สัดส่วนค่าใช้จ่าย" icon={<PieChart size={18} className="text-mint" />}>
          <ExpensePie data={expenseBreakdown(transactions)} />
        </Panel>
        <Panel title="ผลงานรายเดือน" icon={<BarChart3 size={18} className="text-mint" />}>
          <MonthlyComparison data={monthly} />
        </Panel>
      </div>
    </AppShell>
  );
}
