import { AppShell } from "@/components/app-shell";
import { MetricCard } from "@/components/metric-card";
import { ExpensePie, MonthlyComparison, ProfitLine, RevenueTrend } from "@/components/charts";
import { Panel } from "@/components/panel";
import { Insights } from "@/components/insights";
import { TransactionTable } from "@/components/transaction-table";
import { QuickAddButton } from "@/components/QuickAddButton";
import { getAllTransactions } from "@/lib/storage";
import {
  adaptTransactions,
  dailySeries,
  expenseBreakdown,
  generateInsights,
  groupByMonth,
  monthlyReports,
  summarizeTransactions,
} from "@/lib/finance";
import { AreaChart, BarChart3, TrendingUp, Receipt, Wallet } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const raw = await getAllTransactions();
  const transactions = adaptTransactions(raw);
  const monthly = groupByMonth(transactions);
  const reports = monthlyReports(monthly);
  const summary = summarizeTransactions(transactions);
  const series = dailySeries(transactions);
  const sparks = series.map((item) => ({ value: item.income }));
  const insights = generateInsights(transactions, monthly);

  return (
    <AppShell
      title="แดชบอร์ดการเงินร้านปันสุข"
      subtitle="สรุปรายรับ ต้นทุน ค่าใช้จ่าย กำไร และกระแสเงินสดแบบ real-time"
      headerRight={<QuickAddButton />}
    >
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
        <MetricCard label="รายรับรวม" value={summary.totalIncome} trend={12.4} data={sparks} accent="#0EA5E9" icon={<TrendingUp size={16} color="#0EA5E9" />} />
        <MetricCard label="ต้นทุนและค่าใช้จ่าย" value={summary.totalExpenses + summary.totalCost} trend={8.1} data={series.map((item) => ({ value: item.expenses }))} accent="#F43F5E" icon={<Receipt size={16} color="#F43F5E" />} />
        <MetricCard label="กำไรสุทธิ" value={summary.netProfit} trend={6.8} data={series.map((item) => ({ value: item.profit }))} accent="#10B981" icon={<Wallet size={16} color="#10B981" />} />
        <MetricCard label="กำไรเดือนล่าสุด" value={reports.at(-1)?.netProfit ?? 0} trend={14.2} data={reports.map((item) => ({ value: item.netProfit }))} accent="#6366F1" icon={<BarChart3 size={16} color="#6366F1" />} />
        <MetricCard label="กระแสเงินสด" value={summary.remainingCashFlow} trend={4.9} data={series.map((item) => ({ value: item.cashFlow }))} accent="#A78BFA" icon={<AreaChart size={16} color="#A78BFA" />} />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[1.5fr_.8fr]">
        <Panel title="รายรับเทียบค่าใช้จ่าย" icon={<TrendingUp size={18} className="text-mint" />}>
          <RevenueTrend data={series} />
        </Panel>
        <Panel title="ข้อมูลเชิงลึก">
          <Insights insights={insights} />
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-3">
        <Panel title="กำไรและกระแสเงินสด" className="xl:col-span-2">
          <ProfitLine data={series} />
        </Panel>
        <Panel title="สัดส่วนค่าใช้จ่าย">
          <ExpensePie data={expenseBreakdown(transactions)} />
        </Panel>
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[.9fr_1.1fr]">
        <Panel title="เปรียบเทียบรายเดือน" icon={<BarChart3 size={18} className="text-mint" />}>
          <MonthlyComparison data={monthly} />
        </Panel>
        <TransactionTable records={transactions.slice(0, 20)} />
      </div>
    </AppShell>
  );
}
