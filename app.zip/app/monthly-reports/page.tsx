import { AppShell } from "@/components/app-shell";
import { Panel } from "@/components/panel";
import { ReportActions } from "@/components/report-actions";
import { getAllTransactions } from "@/lib/storage";
import { adaptTransactions, currency, groupByMonth, monthlyReports } from "@/lib/finance";
import { FileSpreadsheet, PackageOpen } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function MonthlyReportsPage() {
  const raw = await getAllTransactions();
  const transactions = adaptTransactions(raw);
  const monthly = groupByMonth(transactions);
  const reports = monthlyReports(monthly);

  const sorted = [...transactions].sort((a, b) => b.remainingBalance - a.remainingBalance);
  const best = sorted[0];
  const worst = sorted[sorted.length - 1];
  const hasData = transactions.length > 0 || monthly.length > 0;

  return (
    <AppShell title="รายงานรายเดือน" subtitle="สรุปผลประกอบการพร้อมส่งออกหรือพิมพ์รายงาน">
      <Panel
        title="สรุปผลการเงินจากข้อมูลจริง"
        icon={<FileSpreadsheet size={18} className="text-mint" />}
        action={<ReportActions reports={monthly} />}
      >
        {!hasData ? (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <PackageOpen size={48} className="text-slate-300" />
            <p className="mt-4 text-lg font-semibold text-slate-500">ยังไม่มีข้อมูล</p>
            <p className="mt-1 text-sm text-slate-400">เพิ่มรายการรายรับ-รายจ่ายเพื่อเริ่มต้นสร้างรายงาน</p>
          </div>
        ) : (
          <>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border border-emerald-100 bg-emerald-50/60 p-5">
                <p className="text-sm text-slate-500">รายการที่มียอดสูงสุด</p>
                <p className="mt-2 text-2xl font-bold text-ink">{best?.date ?? "—"}</p>
                <p className="mt-1 text-sm font-semibold text-gold">{best ? currency.format(best.remainingBalance) : "—"} คงเหลือ</p>
              </div>
              <div className="rounded-2xl border border-rose-100 bg-rose-50/60 p-5">
                <p className="text-sm text-slate-500">รายการที่มียอดต่ำสุด</p>
                <p className="mt-2 text-2xl font-bold text-ink">{worst?.date ?? "—"}</p>
                <p className="mt-1 text-sm font-semibold text-coral">{worst ? currency.format(worst.remainingBalance) : "—"} คงเหลือ</p>
              </div>
            </div>
            <div className="mt-6 overflow-x-auto">
              <table className="w-full min-w-[720px] text-left text-sm">
                <thead className="text-xs uppercase tracking-[0.14em] text-slate-400">
                  <tr>
                    <th className="py-3">เดือน</th>
                    <th>รายรับ</th>
                    <th>ต้นทุน</th>
                    <th>ค่าใช้จ่าย</th>
                    <th>กำไรสุทธิ</th>
                    <th>มาร์จิน</th>
                    <th>เติบโต</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {reports.map((item) => (
                    <tr key={item.key ?? item.month} className="transition hover:bg-slate-50/80">
                      <td className="py-4 font-semibold text-ink">{item.month}</td>
                      <td className="text-slate-600">{currency.format(item.income)}</td>
                      <td className="text-slate-600">{currency.format(item.cost)}</td>
                      <td className="text-slate-600">{currency.format(item.expenses)}</td>
                      <td className="font-bold text-gold">{currency.format(item.netProfit)}</td>
                      <td className="text-slate-600">{(item.margin * 100).toFixed(1)}%</td>
                      <td className={item.growth >= 0 ? "font-semibold text-gold" : "font-semibold text-coral"}>
                        {(item.growth * 100).toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </Panel>
    </AppShell>
  );
}
