import { AppShell } from "@/components/app-shell";
import { ProfitLine } from "@/components/charts";
import { MetricCard } from "@/components/metric-card";
import { Panel } from "@/components/panel";
import { getAllTransactions } from "@/lib/storage";
import { adaptTransactions, dailySeries, summarizeTransactions } from "@/lib/finance";
import { Banknote, Receipt, Wallet } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function CashFlowPage() {
  const raw = await getAllTransactions();
  const transactions = adaptTransactions(raw);
  const series = dailySeries(transactions);
  const summary = summarizeTransactions(transactions);

  return (
    <AppShell title="กระแสเงินสด" subtitle="ติดตามยอดคงเหลือ กำไรเฉลี่ยต่อวัน และสุขภาพเงินสดของร้าน">
      <div className="grid gap-4 md:grid-cols-3">
        <MetricCard label="กระแสเงินสดคงเหลือ" value={summary.remainingCashFlow} trend={4.9} data={series.map((item) => ({ value: item.cashFlow }))} accent="#6366F1" icon={<Wallet size={16} color="#6366F1" />} />
        <MetricCard label="กำไรเฉลี่ยต่อรายการ" value={transactions.length > 0 ? summary.netProfit / transactions.length : 0} trend={2.7} data={series.map((item) => ({ value: item.profit }))} accent="#10B981" icon={<Banknote size={16} color="#10B981" />} />
        <MetricCard label="ค่าใช้จ่ายดำเนินงาน" value={summary.totalExpenses} trend={8.1} data={series.map((item) => ({ value: item.expenses }))} accent="#F43F5E" icon={<Receipt size={16} color="#F43F5E" />} />
      </div>
      <div className="mt-6">
        <Panel title="กราฟกระแสเงินสด">
          <ProfitLine data={series} />
        </Panel>
      </div>
    </AppShell>
  );
}
