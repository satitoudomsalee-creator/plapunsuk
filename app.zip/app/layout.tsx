import type { Metadata } from "next";
import "./globals.css";
import { ToastProvider } from "@/components/Toast";

export const metadata: Metadata = {
  title: "ปันสุข Finance | แดชบอร์ดการเงินธุรกิจ",
  description: "แดชบอร์ดการเงินสำหรับดูรายรับ ต้นทุน ค่าใช้จ่าย กำไร และรายงานรายเดือนจากไฟล์ Excel"
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="th">
      <body>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  );
}
