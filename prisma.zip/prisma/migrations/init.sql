-- CreateEnum for TransactionKind
CREATE TYPE "TransactionKind" AS ENUM ('INCOME', 'COST', 'EXPENSE', 'ADJUSTMENT');

-- CreateEnum for ReportStatus
CREATE TYPE "ReportStatus" AS ENUM ('DRAFT', 'FINAL', 'EXPORTED');

-- CreateTable User
CREATE TABLE "User" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "email" TEXT NOT NULL UNIQUE,
  "name" TEXT,
  "avatarUrl" TEXT,
  "businessName" TEXT,
  "currency" TEXT NOT NULL DEFAULT 'THB',
  "locale" TEXT NOT NULL DEFAULT 'th-TH',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL
);

-- CreateTable Transaction
CREATE TABLE "Transaction" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "categoryId" TEXT,
  "sourceSheet" TEXT,
  "sourceRow" INTEGER,
  "date" TIMESTAMP(3) NOT NULL,
  "kind" "TransactionKind" NOT NULL DEFAULT 'INCOME',
  "income" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "productCost" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "otherExpense" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "remainingBalance" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "notes" TEXT,
  "tags" TEXT[] DEFAULT ARRAY[]::TEXT[],
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Transaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE,
  CONSTRAINT "Transaction_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "ExpenseCategory" ("id") ON DELETE SET NULL
);

-- CreateIndex for Transaction
CREATE INDEX "Transaction_userId_date_idx" ON "Transaction"("userId", "date");
CREATE INDEX "Transaction_userId_categoryId_idx" ON "Transaction"("userId", "categoryId");

-- CreateTable ExpenseCategory
CREATE TABLE "ExpenseCategory" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "color" TEXT NOT NULL DEFAULT '#5EEAD4',
  "icon" TEXT NOT NULL DEFAULT 'Tag',
  "isDefault" BOOLEAN NOT NULL DEFAULT false,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ExpenseCategory_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE,
  CONSTRAINT "ExpenseCategory_userId_name_key" UNIQUE("userId", "name")
);

-- CreateTable MonthlySummary
CREATE TABLE "MonthlySummary" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "month" TIMESTAMP(3) NOT NULL,
  "totalIncome" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "totalCost" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "totalExpense" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "netProfit" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "cashFlow" NUMERIC(14,2) NOT NULL DEFAULT 0,
  "profitMargin" NUMERIC(7,4) NOT NULL DEFAULT 0,
  "bestDay" TIMESTAMP(3),
  "worstDay" TIMESTAMP(3),
  "generatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MonthlySummary_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE,
  CONSTRAINT "MonthlySummary_userId_month_key" UNIQUE("userId", "month")
);

-- CreateTable Report
CREATE TABLE "Report" (
  "id" TEXT NOT NULL PRIMARY KEY,
  "userId" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "periodStart" TIMESTAMP(3) NOT NULL,
  "periodEnd" TIMESTAMP(3) NOT NULL,
  "status" "ReportStatus" NOT NULL DEFAULT 'DRAFT',
  "payload" JSONB NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Report_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE
);

-- CreateIndex for Report
CREATE INDEX "Report_userId_periodStart_periodEnd_idx" ON "Report"("userId", "periodStart", "periodEnd");
