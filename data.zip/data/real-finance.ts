import type { MonthlyReport, TransactionRecord } from "@/lib/types";

export const realTransactions: TransactionRecord[] = [];

export const realMonthlyReports: MonthlyReport[] = [];

export const realFinanceSummary = {
  totalIncome: 0,
  totalCost: 0,
  totalExpenses: 0,
  netProfit: 0,
  recordCount: 0
};
