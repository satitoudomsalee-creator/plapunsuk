import { addDays, format, startOfMonth } from "date-fns";
import type { TransactionRecord } from "@/lib/types";

const monthStart = startOfMonth(new Date(2026, 4, 1));
const notes = [
  "Retail sales and card payments",
  "Online orders settled",
  "Corporate invoice paid",
  "Weekend walk-in revenue",
  "Marketplace payout",
  "Subscription client payment"
];
const categories = ["Inventory", "Rent", "Utilities", "Marketing", "Software", "Logistics"];

export const transactions: TransactionRecord[] = Array.from({ length: 31 }, (_, index) => {
  const day = addDays(monthStart, index);
  const weekendLift = [5, 6].includes(day.getDay()) ? 1.22 : 1;
  const income = Math.round((8200 + Math.sin(index / 2.8) * 2100 + index * 95) * weekendLift);
  const productCost = Math.round(income * (0.32 + ((index % 5) * 0.012)));
  const otherExpense = Math.round(1050 + (index % 7) * 260 + (index === 12 ? 5200 : 0));
  const remainingBalance = income - productCost - otherExpense;

  return {
    id: `txn-${index + 1}`,
    date: format(day, "yyyy-MM-dd"),
    income,
    productCost,
    otherExpense,
    remainingBalance,
    notes: notes[index % notes.length],
    category: categories[index % categories.length],
    tags: index % 6 === 0 ? ["recurring", "review"] : index % 3 === 0 ? ["growth"] : ["daily"]
  };
});

export const historicalMonths = [
  { month: "Jan", income: 211000, cost: 73600, expenses: 39200 },
  { month: "Feb", income: 226500, cost: 78100, expenses: 41100 },
  { month: "Mar", income: 219300, cost: 76800, expenses: 44800 },
  { month: "Apr", income: 244900, cost: 81700, expenses: 46200 },
  { month: "May", income: 276800, cost: 92600, expenses: 53600 }
].map((item) => ({
  ...item,
  netProfit: item.income - item.cost - item.expenses,
  cashFlow: item.income - item.cost - item.expenses,
  margin: (item.income - item.cost - item.expenses) / item.income
}));
