"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { currency } from "@/lib/finance";

const colors = ["#0EA5E9", "#6366F1", "#10B981", "#F43F5E", "#A78BFA", "#F59E0B"];

type DailyChartPoint = {
  date: string;
  income: number;
  expenses: number;
  profit: number;
  cashFlow: number;
};

type ExpensePoint = {
  name: string;
  value: number;
};

type MonthlyPoint = {
  month: string;
  income: number;
  netProfit: number;
};

type ChartTooltipPayload = {
  dataKey?: string | number;
  color?: string;
  name?: string | number;
  value?: string | number;
};

function ChartTooltip({
  active,
  payload,
  label
}: {
  active?: boolean;
  payload?: ChartTooltipPayload[];
  label?: string | number;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border border-line bg-white/95 p-3 text-sm shadow-glass backdrop-blur">
      <p className="mb-2 font-medium text-slate-500">{label}</p>
      {payload.map((item) => (
        <p key={String(item.dataKey)} style={{ color: item.color }} className="font-semibold">
          {item.name}: {currency.format(Number(item.value ?? 0))}
        </p>
      ))}
    </div>
  );
}

export function RevenueTrend({ data }: { data: DailyChartPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={320}>
      <AreaChart data={data}>
        <defs>
          <linearGradient id="incomeFill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#0EA5E9" stopOpacity={0.25} />
            <stop offset="95%" stopColor="#0EA5E9" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="rgba(15,23,42,0.06)" vertical={false} />
        <XAxis dataKey="date" stroke="#94A3B8" tickLine={false} axisLine={false} tick={{ fontSize: 12 }} />
        <YAxis stroke="#94A3B8" tickLine={false} axisLine={false} tick={{ fontSize: 12 }} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
        <Tooltip content={<ChartTooltip />} />
        <Area name="รายรับ" type="monotone" dataKey="income" stroke="#0EA5E9" strokeWidth={3} fill="url(#incomeFill)" dot={false} />
        <Area name="ค่าใช้จ่าย" type="monotone" dataKey="expenses" stroke="#F43F5E" strokeWidth={2} fill="transparent" dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function ProfitLine({ data }: { data: DailyChartPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <LineChart data={data}>
        <CartesianGrid stroke="rgba(15,23,42,0.06)" vertical={false} />
        <XAxis dataKey="date" stroke="#94A3B8" tickLine={false} axisLine={false} tick={{ fontSize: 12 }} />
        <YAxis stroke="#94A3B8" tickLine={false} axisLine={false} tick={{ fontSize: 12 }} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
        <Tooltip content={<ChartTooltip />} />
        <Line name="กำไร" type="monotone" dataKey="profit" stroke="#10B981" strokeWidth={3} dot={false} />
        <Line name="กระแสเงินสด" type="monotone" dataKey="cashFlow" stroke="#6366F1" strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function ExpensePie({ data }: { data: ExpensePoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart>
        <Tooltip content={<ChartTooltip />} />
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={66} outerRadius={106} paddingAngle={4}>
          {data.map((_, index) => (
            <Cell key={index} fill={colors[index % colors.length]} />
          ))}
        </Pie>
      </PieChart>
    </ResponsiveContainer>
  );
}

export function MonthlyComparison({ data }: { data: MonthlyPoint[] }) {
  return (
    <ResponsiveContainer width="100%" height={320}>
      <BarChart data={data}>
        <CartesianGrid stroke="rgba(15,23,42,0.06)" vertical={false} />
        <XAxis dataKey="month" stroke="#94A3B8" tickLine={false} axisLine={false} tick={{ fontSize: 12 }} />
        <YAxis stroke="#94A3B8" tickLine={false} axisLine={false} tick={{ fontSize: 12 }} tickFormatter={(v) => `${Math.round(v / 1000)}k`} />
        <Tooltip content={<ChartTooltip />} />
        <Bar name="รายรับ" dataKey="income" fill="#0EA5E9" radius={[8, 8, 0, 0]} />
        <Bar name="กำไรสุทธิ" dataKey="netProfit" fill="#10B981" radius={[8, 8, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
