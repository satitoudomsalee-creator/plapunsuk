"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { useRouter } from "next/navigation";
import { TransactionModal } from "./TransactionModal";
import type { Transaction } from "@/lib/types";

export function QuickAddButton() {
  const [open, setOpen] = useState(false);
  const router = useRouter();

  function handleSuccess(_: Transaction) {
    // Revalidate the Server Component so KPI cards refresh
    router.refresh();
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="inline-flex items-center gap-2 rounded-full bg-mint px-4 py-2 text-sm font-semibold text-white shadow-glow transition hover:bg-ocean active:scale-95"
      >
        <Plus size={16} />
        เพิ่มรายการ
      </button>
      <TransactionModal
        open={open}
        mode="create"
        onSuccess={handleSuccess}
        onClose={() => setOpen(false)}
      />
    </>
  );
}
