"use client";

import { useRef, useState } from "react";
import { CheckCircle2, Loader2, Upload } from "lucide-react";
import { currency } from "@/lib/finance";

type ImportResult = {
  fileName: string;
  records: unknown[];
  summary: {
    totalIncome: number;
    totalCost: number;
    totalExpenses: number;
    netProfit: number;
  };
};

export function ImportUploader() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [error, setError] = useState("");

  async function upload(file: File) {
    setLoading(true);
    setError("");
    const form = new FormData();
    form.append("file", file);

    const response = await fetch("/api/import", { method: "POST", body: form });
    const data = await response.json();
    setLoading(false);

    if (!response.ok) {
      setError(data.error ?? "Import failed.");
      return;
    }

    setResult(data);
  }

  return (
    <div className="rounded-2xl border-2 border-dashed border-mint/30 bg-cloud/40 p-8 text-center">
      <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-mint/10">
        <Upload className="text-mint" size={28} />
      </div>
      <h2 className="mt-4 text-xl font-semibold text-ink">เลือกไฟล์รายงานการเงิน Excel</h2>
      <p className="mx-auto mt-2 max-w-md text-sm text-slate-500">ระบบอ่านรายรับ ต้นทุน ค่าใช้จ่าย ยอดคงเหลือ หมายเหตุ และชื่อชีตรายเดือนอัตโนมัติ</p>
      <input
        ref={inputRef}
        type="file"
        accept=".xlsx,.xls,.csv"
        className="hidden"
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void upload(file);
        }}
      />
      <button onClick={() => inputRef.current?.click()} className="mt-6 inline-flex items-center gap-2 rounded-full bg-mint px-6 py-3 font-semibold text-white shadow-glow transition hover:bg-ocean active:scale-95">
        {loading && <Loader2 className="animate-spin" size={17} />}
        {loading ? "กำลังอ่านไฟล์..." : "อัปโหลด Excel"}
      </button>
      {error && <p className="mt-4 text-sm text-coral">{error}</p>}
      {result && (
        <div className="mx-auto mt-6 max-w-xl rounded-2xl border border-emerald-100 bg-emerald-50/60 p-4 text-left">
          <div className="flex items-center gap-2 text-gold">
            <CheckCircle2 size={18} />
            <span className="font-semibold text-ink">นำเข้า {result.fileName} แล้ว</span>
          </div>
          <div className="mt-4 grid gap-3 text-sm sm:grid-cols-2">
            <p className="text-slate-500">จำนวนรายการ <span className="float-right font-semibold text-ink">{result.records.length}</span></p>
            <p className="text-slate-500">รายรับ <span className="float-right font-semibold text-ink">{currency.format(result.summary.totalIncome)}</span></p>
            <p className="text-slate-500">ค่าใช้จ่าย <span className="float-right font-semibold text-ink">{currency.format(result.summary.totalExpenses + result.summary.totalCost)}</span></p>
            <p className="text-slate-500">กำไรสุทธิ <span className="float-right font-semibold text-gold">{currency.format(result.summary.netProfit)}</span></p>
          </div>
        </div>
      )}
    </div>
  );
}
