"use client";

import { Download, FileDown, Printer } from "lucide-react";
import type { MonthlyReport } from "@/lib/types";

export function ReportActions({ reports }: { reports: MonthlyReport[] }) {
  function exportCsv() {
    const rows = [
      ["Month", "Income", "Cost", "Expenses", "Net Profit", "Cash Flow", "Margin"],
      ...reports.map((item) => [item.month, item.income, item.cost, item.expenses, item.netProfit, item.cashFlow, item.margin])
    ];
    const csv = rows.map((row) => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "monthly-finance-report.csv";
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex gap-2">
      <button onClick={() => window.print()} className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-slate-50 text-slate-500 transition hover:bg-slate-100 hover:text-ink" title="Export PDF">
        <FileDown size={16} />
      </button>
      <button onClick={exportCsv} className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-slate-50 text-slate-500 transition hover:bg-slate-100 hover:text-ink" title="Export CSV">
        <Download size={16} />
      </button>
      <button onClick={() => window.print()} className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-slate-50 text-slate-500 transition hover:bg-slate-100 hover:text-ink" title="Print">
        <Printer size={16} />
      </button>
    </div>
  );
}
