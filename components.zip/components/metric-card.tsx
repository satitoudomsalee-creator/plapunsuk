"use client";

import { motion } from "framer-motion";
import { Area, AreaChart, ResponsiveContainer } from "recharts";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import { currency } from "@/lib/finance";
import { cn } from "@/lib/utils";

export function MetricCard({
  label,
  value,
  trend,
  data,
  accent = "#0EA5E9",
  icon
}: {
  label: string;
  value: number;
  trend: number;
  data: { value: number }[];
  accent?: string;
  icon?: React.ReactNode;
}) {
  const positive = trend >= 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4, boxShadow: "0 20px 60px rgba(15,23,42,0.12)" }}
      className="glass rounded-2xl p-6 transition"
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex items-center gap-2">
          {icon && (
            <div className="grid h-8 w-8 shrink-0 place-items-center rounded-xl" style={{ backgroundColor: `${accent}18` }}>
              {icon}
            </div>
          )}
          <p className="text-sm font-medium text-slate-500">{label}</p>
        </div>
        <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold", positive ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-600")}>
          {positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
          {Math.abs(trend).toFixed(1)}%
        </span>
      </div>
      <p className="mt-3 text-2xl font-bold tracking-tight text-ink sm:text-3xl">{currency.format(value)}</p>
      <div className="mt-4 h-16">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id={`${label}-spark`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={accent} stopOpacity={0.3} />
                <stop offset="95%" stopColor={accent} stopOpacity={0} />
              </linearGradient>
            </defs>
            <Area type="monotone" dataKey="value" stroke={accent} strokeWidth={2} fill={`url(#${label}-spark)`} dot={false} isAnimationActive />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
