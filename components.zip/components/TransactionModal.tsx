"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";
import { TransactionForm } from "./TransactionForm";
import type { Transaction } from "@/lib/types";

type Props = {
  open: boolean;
  mode: "create" | "edit";
  initialData?: Partial<Transaction>;
  onSuccess: (t: Transaction) => void;
  onClose: () => void;
};

export function TransactionModal({ open, mode, initialData, onSuccess, onClose }: Props) {
  const overlayRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onClose]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  if (!mounted) return null;

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          ref={overlayRef}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={(e) => { if (e.target === overlayRef.current) onClose(); }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-ink/20 px-4 backdrop-blur-sm"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 8 }}
            transition={{ type: "spring", stiffness: 380, damping: 32 }}
            className="glass w-full max-w-lg overflow-y-auto rounded-3xl p-7 shadow-glass"
            style={{ maxHeight: "90dvh" }}
          >
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-bold text-ink">
                {mode === "create" ? "เพิ่มรายการใหม่" : "แก้ไขรายการ"}
              </h2>
              <button
                onClick={onClose}
                className="grid h-9 w-9 place-items-center rounded-xl border border-line bg-slate-50 text-slate-400 transition hover:bg-slate-100 hover:text-ink"
              >
                <X size={18} />
              </button>
            </div>
            <TransactionForm
              mode={mode}
              initialData={initialData}
              onSuccess={(t) => { onSuccess(t); onClose(); }}
              onCancel={onClose}
            />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  );
}
