"use client";

import { AlertTriangle, CheckCircle2, Sparkles } from "lucide-react";
import { motion } from "framer-motion";
import type { Insight } from "@/lib/types";

export function Insights({ insights }: { insights: Insight[] }) {
  const icon = {
    good: CheckCircle2,
    warning: AlertTriangle,
    neutral: Sparkles
  };

  const toneStyle = {
    good: "border-emerald-100 bg-emerald-50/60",
    warning: "border-amber-100 bg-amber-50/60",
    neutral: "border-sky-100 bg-sky-50/60"
  };

  const iconStyle = {
    good: "text-gold",
    warning: "text-amber-500",
    neutral: "text-mint"
  };

  if (insights.length === 0) {
    return (
      <div className="flex flex-col items-center py-10 text-center">
        <Sparkles size={32} className="text-mint/50" />
        <p className="mt-3 text-sm text-slate-500">อัปโหลด Excel เพื่อดูข้อมูลเชิงลึก</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {insights.map((item, index) => {
        const Icon = icon[item.tone];
        return (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, x: 16 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.08 }}
            className={`rounded-xl border p-4 ${toneStyle[item.tone]}`}
          >
            <div className="flex gap-3">
              <Icon className={iconStyle[item.tone]} size={19} />
              <div>
                <p className="font-semibold text-ink">{item.title}</p>
                <p className="mt-1 text-sm text-slate-500">{item.detail}</p>
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
