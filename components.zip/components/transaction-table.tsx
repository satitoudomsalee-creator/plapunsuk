"use client";

import { useMemo, useState } from "react";
import { Edit3, Inbox, Plus, Search, Trash2 } from "lucide-react";
import type { TransactionRecord } from "@/lib/types";
import { currency } from "@/lib/finance";

export function TransactionTable({ records }: { records: TransactionRecord[] }) {
  const [query, setQuery] = useState("");
  const filtered = useMemo(
    () => records.filter((item) => `${item.date} ${item.notes} ${item.category} ${item.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase())),
    [query, records]
  );

  return (
    <div className="glass rounded-2xl p-6">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-ink">รายการจาก Excel</h2>
          <p className="text-sm text-slate-500">ข้อมูลรายวันจริงจากไฟล์ ปันสุข.xlsx</p>
        </div>
        <button className="inline-flex items-center justify-center gap-2 rounded-full bg-mint px-4 py-2 text-sm font-semibold text-white transition hover:bg-ocean active:scale-95">
          <Plus size={16} />
          เพิ่มรายการ
        </button>
      </div>
      <div className="mt-5 flex items-center gap-3 rounded-xl border border-line bg-slate-50/60 px-4 py-3">
        <Search size={18} className="shrink-0 text-slate-400" />
        <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="ค้นหาวันที่ หมายเหตุ หมวดหมู่ หรือแท็ก" className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-slate-400" />
      </div>

      {records.length === 0 ? (
        <div className="flex flex-col items-center py-16 text-center">
          <Inbox size={40} className="text-slate-300" />
          <p className="mt-4 font-medium text-slate-500">ยังไม่มีข้อมูล</p>
          <p className="mt-1 text-sm text-slate-400">อัปโหลด Excel เพื่อเริ่มต้น</p>
        </div>
      ) : (
        <>
          <div className="mt-5 overflow-x-auto">
            <table className="w-full min-w-[860px] border-separate border-spacing-y-2 text-left text-sm">
              <thead className="text-xs uppercase tracking-[0.16em] text-slate-400">
                <tr>
                  <th className="px-4 py-2">วันที่</th>
                  <th className="px-4 py-2">รายรับ</th>
                  <th className="px-4 py-2">ต้นทุน</th>
                  <th className="px-4 py-2">ค่าใช้จ่ายอื่น</th>
                  <th className="px-4 py-2">คงเหลือ</th>
                  <th className="px-4 py-2">หมวดหมู่</th>
                  <th className="px-4 py-2">หมายเหตุ</th>
                  <th className="px-4 py-2">จัดการ</th>
                </tr>
              </thead>
              <tbody>
                {filtered.slice(0, 12).map((item) => (
                  <tr key={item.id} className="bg-slate-50/60 transition hover:bg-slate-100/80">
                    <td className="rounded-l-xl px-4 py-3 text-slate-600">{item.date}</td>
                    <td className="px-4 py-3 font-medium text-mint">{currency.format(item.income)}</td>
                    <td className="px-4 py-3 text-slate-600">{currency.format(item.productCost)}</td>
                    <td className="px-4 py-3 text-coral">{currency.format(item.otherExpense)}</td>
                    <td className="px-4 py-3 font-bold text-ink">{currency.format(item.remainingBalance)}</td>
                    <td className="px-4 py-3">
                      <span className="rounded-full bg-mint/10 px-3 py-1 text-xs font-medium text-mint">{item.category}</span>
                    </td>
                    <td className="max-w-[220px] truncate px-4 py-3 text-slate-400">{item.notes}</td>
                    <td className="rounded-r-xl px-4 py-3">
                      <div className="flex gap-2">
                        <button className="grid h-8 w-8 place-items-center rounded-full bg-slate-100 text-slate-500 hover:bg-mint/10 hover:text-mint transition" title="Edit">
                          <Edit3 size={15} />
                        </button>
                        <button className="grid h-8 w-8 place-items-center rounded-full bg-slate-100 text-slate-500 hover:bg-rose-50 hover:text-coral transition" title="Delete">
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex items-center justify-between text-sm text-slate-400">
            <span>แสดง {Math.min(filtered.length, 12)} จาก {filtered.length} รายการ</span>
            <div className="flex gap-2">
              <button className="rounded-full border border-line bg-white px-3 py-1.5 text-slate-600 hover:bg-slate-50 transition">ก่อนหน้า</button>
              <button className="rounded-full border border-line bg-white px-3 py-1.5 text-slate-600 hover:bg-slate-50 transition">ถัดไป</button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
