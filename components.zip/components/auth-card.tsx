import Link from "next/link";
import { Chrome, WalletCards } from "lucide-react";

export function AuthCard({ mode }: { mode: "login" | "register" }) {
  const isLogin = mode === "login";

  return (
    <main className="relative grid min-h-screen place-items-center overflow-hidden px-4 py-10">
      <div className="soft-grid pointer-events-none absolute inset-0 opacity-60" />
      <section className="glass relative w-full max-w-md rounded-3xl p-8">
        <Link href="/dashboard" className="mb-8 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-mint/10 text-mint ring-1 ring-mint/20">
            <WalletCards size={22} />
          </div>
          <div>
            <p className="text-lg font-bold tracking-tight text-ink">ปันสุข Finance</p>
            <p className="text-xs text-slate-500">เห็นเงินธุรกิจชัดขึ้นในหน้าเดียว</p>
          </div>
        </Link>
        <h1 className="text-3xl font-bold tracking-tight text-ink">{isLogin ? "ยินดีต้อนรับกลับ" : "สร้างพื้นที่การเงินของธุรกิจ"}</h1>
        <p className="mt-2 text-sm text-slate-500">{isLogin ? "เข้าสู่ระบบเพื่อดูรายรับ กำไร กระแสเงินสด และค่าใช้จ่าย" : "เริ่มจากนำเข้า Excel แล้วเปลี่ยนเป็นแดชบอร์ดการเงินแบบสด"}</p>

        <button className="mt-7 flex w-full items-center justify-center gap-2 rounded-full border border-line bg-white px-4 py-3 font-semibold text-ink shadow-glass transition hover:bg-slate-50 active:scale-95">
          <Chrome size={18} className="text-slate-500" />
          เข้าสู่ระบบด้วย Google
        </button>

        <div className="my-6 flex items-center gap-3 text-xs text-slate-400">
          <span className="h-px flex-1 bg-line" />
          or
          <span className="h-px flex-1 bg-line" />
        </div>

        <form className="space-y-4">
          {!isLogin && (
            <input
              className="w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition placeholder:text-slate-400 focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
              placeholder="ชื่อธุรกิจ"
            />
          )}
          <input
            className="w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition placeholder:text-slate-400 focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
            placeholder="อีเมล"
            type="email"
          />
          <input
            className="w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition placeholder:text-slate-400 focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
            placeholder="รหัสผ่าน"
            type="password"
          />
          <button className="w-full rounded-full bg-mint px-4 py-3 font-semibold text-white shadow-glow transition hover:bg-ocean active:scale-95">
            {isLogin ? "เข้าสู่ระบบ" : "สมัครใช้งาน"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-slate-500">
          {isLogin ? "ยังไม่มีบัญชี? " : "มีบัญชีแล้ว? "}
          <Link className="font-semibold text-mint hover:text-ocean" href={isLogin ? "/register" : "/login"}>
            {isLogin ? "สมัครใช้งาน" : "เข้าสู่ระบบ"}
          </Link>
        </p>
      </section>
    </main>
  );
}
