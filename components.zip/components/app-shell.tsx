"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  AreaChart,
  BarChart3,
  Bell,
  CreditCard,
  FileSpreadsheet,
  LayoutDashboard,
  LineChart,
  ReceiptText,
  Settings,
  SunMedium,
  WalletCards
} from "lucide-react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

const menu = [
  { href: "/dashboard", label: "ภาพรวม", icon: LayoutDashboard },
  { href: "/transactions", label: "รายการรายวัน", icon: ReceiptText },
  { href: "/profit-loss", label: "กำไรขาดทุน", icon: LineChart },
  { href: "/analytics", label: "วิเคราะห์", icon: BarChart3 },
  { href: "/monthly-reports", label: "รายงานรายเดือน", icon: FileSpreadsheet },
  { href: "/cash-flow", label: "กระแสเงินสด", icon: AreaChart },
  { href: "/settings", label: "ตั้งค่า", icon: Settings }
];

export function AppShell({ children, title, subtitle, headerRight }: { children: React.ReactNode; title: string; subtitle: string; headerRight?: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <main className="relative min-h-screen overflow-hidden text-ink">
      <div className="soft-grid pointer-events-none absolute inset-0 opacity-60" />
      <div className="relative flex min-h-screen">
        <aside className="sticky top-0 hidden h-screen w-72 shrink-0 border-r border-line bg-white/80 p-5 backdrop-blur-2xl lg:block">
          <Link href="/dashboard" className="mb-8 flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-mint/10 text-mint ring-1 ring-mint/30">
              <WalletCards size={22} />
            </div>
            <div>
              <p className="text-lg font-semibold tracking-tight text-ink">ปันสุข Finance</p>
              <p className="text-xs text-slate-500">ระบบดูแลการเงินธุรกิจ</p>
            </div>
          </Link>

          <nav className="space-y-1">
            {menu.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "group flex items-center gap-3 rounded-xl px-4 py-2.5 text-sm transition",
                    active && "bg-mint/10 text-mint shadow-glow font-medium",
                    !active && "text-slate-500 hover:bg-slate-50 hover:text-ink"
                  )}
                >
                  <Icon size={18} className={cn("transition", active ? "text-mint" : "text-slate-400 group-hover:text-mint")} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="glass mt-8 rounded-2xl p-4">
            <p className="text-xs font-semibold uppercase tracking-[0.22em] text-mint">นำเข้าจาก Excel</p>
            <p className="mt-2 text-sm text-slate-500">อ่านรายรับ ต้นทุน ค่าใช้จ่าย และยอดคงเหลือจากไฟล์ ปันสุข.xlsx</p>
            <Link href="/settings" className="mt-4 inline-flex items-center gap-2 rounded-full bg-mint px-4 py-2 text-sm font-semibold text-white transition hover:bg-ocean">
              <CreditCard size={15} />
              จัดการไฟล์
            </Link>
          </div>
        </aside>

        <section className="flex min-w-0 flex-1 flex-col">
          <header className="sticky top-0 z-20 border-b border-line bg-white/80 px-4 py-4 backdrop-blur-2xl sm:px-6 lg:px-8">
            <div className="flex items-center justify-between gap-4">
              <div>
                <motion.h1 initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="text-2xl font-bold tracking-tight text-ink sm:text-3xl">
                  {title}
                </motion.h1>
                <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
              </div>
              <div className="flex items-center gap-2">
                {headerRight}
                <button className="grid h-10 w-10 place-items-center rounded-full border border-line bg-slate-50 text-slate-500 transition hover:bg-slate-100 hover:text-ink" title="Notifications">
                  <Bell size={18} />
                </button>
                <button className="grid h-10 w-10 place-items-center rounded-full border border-line bg-slate-50 text-slate-500 transition hover:bg-slate-100 hover:text-ink" title="Theme">
                  <SunMedium size={18} />
                </button>
              </div>
            </div>
            <nav className="scrollbar-none mt-4 flex gap-2 overflow-x-auto lg:hidden">
              {menu.map((item) => {
                const Icon = item.icon;
                const active = pathname === item.href;
                return (
                  <Link key={item.href} href={item.href} className={cn("flex shrink-0 items-center gap-2 rounded-full border px-3 py-2 text-xs transition", active ? "border-mint/30 bg-mint/10 text-mint font-medium" : "border-line bg-white text-slate-500")}>
                    <Icon size={14} />
                    {item.label}
                  </Link>
                );
              })}
            </nav>
          </header>
          <div className="p-4 sm:p-6 lg:p-8">{children}</div>
        </section>
      </div>
    </main>
  );
}
