"use client";

import { useState } from "react";
import { TrendingDown, TrendingUp, Loader2 } from "lucide-react";
import { useToast } from "./Toast";
import type { Transaction } from "@/lib/types";
import { cn } from "@/lib/utils";

type Props = {
  mode: "create" | "edit";
  initialData?: Partial<Transaction>;
  onSuccess: (t: Transaction) => void;
  onCancel: () => void;
};

const CATEGORIES = ["ขาย", "ค่าเช่า", "ค่าจ้าง", "ค่าวัสดุ", "ค่าน้ำไฟ", "อื่นๆ"];

function today() {
  return new Date().toISOString().slice(0, 10);
}

export function TransactionForm({ mode, initialData, onSuccess, onCancel }: Props) {
  const { addToast } = useToast();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [date, setDate] = useState(initialData?.date ?? today());
  const [type, setType] = useState<"income" | "expense">(initialData?.type ?? "income");
  const [amount, setAmount] = useState(initialData?.amount?.toString() ?? "");
  const [category, setCategory] = useState(initialData?.category ?? "");
  const [notes, setNotes] = useState(initialData?.notes ?? "");

  function validate() {
    const errs: Record<string, string> = {};
    if (!date) errs.date = "กรุณาระบุวันที่";
    const num = Number(amount);
    if (!amount || isNaN(num) || num <= 0) errs.amount = "กรุณาระบุจำนวนเงินที่มากกว่า 0";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      const url =
        mode === "edit" && initialData?.id
          ? `/api/transactions/${initialData.id}`
          : "/api/transactions";
      const method = mode === "edit" ? "PUT" : "POST";

      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, type, amount: Number(amount), category: category || "อื่นๆ", notes }),
      });

      const data = await res.json();
      if (!res.ok) {
        addToast(data.error ?? "เกิดข้อผิดพลาด", "error");
        return;
      }

      addToast(mode === "edit" ? "แก้ไขรายการแล้ว ✓" : "บันทึกรายการแล้ว ✓");
      onSuccess(data as Transaction);
    } catch {
      addToast("เกิดข้อผิดพลาดในการเชื่อมต่อ", "error");
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      {/* Date */}
      <div>
        <label className="block text-sm font-medium text-slate-600 mb-1.5">วันที่</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
        />
        {errors.date && <p className="mt-1 text-xs text-coral">{errors.date}</p>}
      </div>

      {/* Type toggle */}
      <div>
        <label className="block text-sm font-medium text-slate-600 mb-1.5">ประเภท</label>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setType("income")}
            className={cn(
              "flex items-center justify-center gap-2 rounded-2xl border-2 py-4 font-semibold transition",
              type === "income"
                ? "border-mint bg-mint/10 text-mint"
                : "border-line bg-slate-50 text-slate-500 hover:border-mint/30"
            )}
          >
            <TrendingUp size={20} />
            รายรับ
          </button>
          <button
            type="button"
            onClick={() => setType("expense")}
            className={cn(
              "flex items-center justify-center gap-2 rounded-2xl border-2 py-4 font-semibold transition",
              type === "expense"
                ? "border-coral bg-rose-50 text-coral"
                : "border-line bg-slate-50 text-slate-500 hover:border-coral/30"
            )}
          >
            <TrendingDown size={20} />
            รายจ่าย
          </button>
        </div>
      </div>

      {/* Amount */}
      <div>
        <label className="block text-sm font-medium text-slate-600 mb-1.5">จำนวนเงิน</label>
        <div className="relative">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 font-semibold text-slate-400">฿</span>
          <input
            type="number"
            min="0"
            step="any"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0"
            className="w-full rounded-xl border border-line bg-slate-50 py-3 pl-10 pr-4 text-ink outline-none transition focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
          />
        </div>
        {errors.amount && <p className="mt-1 text-xs text-coral">{errors.amount}</p>}
      </div>

      {/* Category — datalist allows preset + free typing */}
      <div>
        <label className="block text-sm font-medium text-slate-600 mb-1.5">หมวดหมู่</label>
        <input
          list="tx-categories"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          placeholder="เลือกหรือพิมพ์หมวดหมู่"
          className="w-full rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
        />
        <datalist id="tx-categories">
          {CATEGORIES.map((c) => <option key={c} value={c} />)}
        </datalist>
      </div>

      {/* Notes */}
      <div>
        <label className="block text-sm font-medium text-slate-600 mb-1.5">
          บันทึก <span className="font-normal text-slate-400">(ไม่บังคับ)</span>
        </label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="หมายเหตุเพิ่มเติม"
          className="w-full resize-none rounded-xl border border-line bg-slate-50 px-4 py-3 text-ink outline-none transition focus:border-mint/40 focus:bg-white focus:ring-2 focus:ring-mint/10"
        />
      </div>

      {/* Buttons */}
      <div className="flex gap-3 pt-1">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 rounded-full border border-line bg-white py-3 font-semibold text-slate-600 transition hover:bg-slate-50 active:scale-95"
        >
          ยกเลิก
        </button>
        <button
          type="submit"
          disabled={loading}
          className="flex-1 inline-flex items-center justify-center gap-2 rounded-full bg-mint py-3 font-semibold text-white shadow-glow transition hover:bg-ocean disabled:opacity-60 active:scale-95"
        >
          {loading && <Loader2 size={17} className="animate-spin" />}
          {loading ? "กำลังบันทึก..." : "บันทึก"}
        </button>
      </div>
    </form>
  );
}
